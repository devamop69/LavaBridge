# Project Brief: Lavalink Proxy

## Overview
Lavalink Proxy is a TCP tunneling proxy server that routes clients to either Lavalink v3 or v4 backends based on client version detection.

## Core Requirements
- Route clients to appropriate Lavalink backend (v3 or v4) based on client version
- Maintain seamless compatibility with existing Lavalink clients
- Provide a modern UI dashboard to monitor connections and system status
- Implement security features to prevent abuse
- Track connection data usage statistics

## Technical Goals
- Maintain high performance with minimal latency overhead
- Support concurrent connections to multiple backend servers
- Provide comprehensive logging and monitoring
- Allow easy configuration through environment variables

## User Experience Goals
- Simple connection URL format compatible with existing Lavalink clients
- User-friendly dashboard for monitoring system status
- Clear display of connection information and statistics
- Dark theme UI with consistent design

## Implementation Details
- Built with Node.js for the backend server
- Modern web UI using Bootstrap and custom CSS
- Real-time monitoring using websockets
- Persistent data storage for usage statistics and security information 